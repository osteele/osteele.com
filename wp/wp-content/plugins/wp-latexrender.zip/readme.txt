Instructions for installing the LatexRender plugin are in readme_plugin.txt
Assuming LaTeX (or alternatively mimeTeX) it's just a case of adjusting some
paths in the files, creating some directories and uploading the files.

You will also find a script which automates the process at 
http://fugato.net/2007/01/20/latex-in-wordpress/ thanks to Gunnlaugur ��r Briem.

There's also some optional beta code users may like to experiment with in the 
offset beta directory. This attempts to improve the vertical alignment of images.
Full details are in the readme_offset.txt in that directory.
