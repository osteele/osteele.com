<?php get_header(); ?>

<div id="toppanel">
	<div id="posts">
	<div class="storycontent">
	
			<div class="post">
				<h2 class="storytitle">404 - These aren't the droids you're looking for..</h2>

				<p>You can go about your business. Move along.</p>
				<p>But really, you've tried to access a page that doesn't exist. Make sure you've spelt the URL correctly and try again, or head back to the main site using the menu above.</p>
			</div>

	</div>
	</div>

</div>

<?php get_footer(); ?>
