<?php include("squible_options.php"); ?>
<!-- begin footer -->
</div>

<div id="credits"><?php bloginfo('name'); ?> is proudly powered by <a href="http://www.wordpress.org">wordpress</a> and <a href="http://www.squible.com/my-work/squible/">Squible <?php echo $squible_version; ?></a>. <br />All content is copyrighted by its author[s].</div>

</div>
<div id="bottom"></div>
</div>

</body>
</html>
