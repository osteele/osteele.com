<? /*
* process whatever you want here but don't make any output! *
*/
$uri=$_POST['nurl'];
header("Location: $uri");
exit();
?>
